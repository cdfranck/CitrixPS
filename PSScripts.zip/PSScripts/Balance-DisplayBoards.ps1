﻿# Load balance Display Boards
Add-PSSnapin citrix*

$started = Get-Date -UFormat '%x %r %Z'

Add-Content C:\Log\rebalance-displayboards.txt -value "Rebalance users on Display board servers after reboot."
Add-Content C:\Log\rebalance-displayboards.txt -value "Started rebalance on $started"
Add-Content C:\Log\rebalance-displayboards.txt -value "------------------------------------------------------"

$totalusers = (Get-BrokerSession -LaunchedViaPublishedName "Epic PRD Display Boards").count
[decimal]$bal=($totalusers/2)
$balanced = [math]::floor($bal)
$ausrcnt = (Get-BrokerSession -LaunchedViaPublishedName "Epic PRD Display Boards" -HostedMachineName "APWCX163").count
$ausers = Get-BrokerSession -LaunchedViaPublishedName "Epic PRD Display Boards" -HostedMachineName "APWCX163" 
$busrcnt = (Get-BrokerSession -LaunchedViaPublishedName "Epic PRD Display Boards" -HostedMachineName "APWCX164").count
$busers = Get-BrokerSession -LaunchedViaPublishedName "Epic PRD Display Boards" -HostedMachineName "APWCX164" 

Add-Content C:\Log\rebalance-displayboards.txt -value "Starting user counts:"
Add-Content C:\Log\rebalance-displayboards.txt -value "$ausrcnt on APWCX163"
Add-Content C:\Log\rebalance-displayboards.txt -value "$busrcnt on APWCX164"

If ($ausrcnt>$balanced) {

    Set-BrokerMachine -MachineName "CHILDRENS\APWCX163" -InMaintenanceMode $true -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
    [decimal]$xa = ($ausrcnt-$balanced)
    $move = [math]::floor($xa)
    Add-Content C:\Log\rebalance-displayboards.txt -value "Move $move from APWCX163"
    $discusers = get-random -Count $move -InputObject $ausers.Uid
    Add-Content C:\Log\rebalance-displayboards.txt -value "Users to be moved from APWCX163 are:"
            foreach ($user in $discusers) {
            Stop-BrokerSession -InputObject $user
            Add-Content C:\Log\rebalance-displayboards.txt -Value (Get-BrokerSession -uid $user | select -ExpandProperty UserName)
            }
    Start-sleep 120 #Wait for disconnected users to relogin
    Set-BrokerMachine -MachineName "CHILDRENS\APWCX163" -InMaintenanceMode $false -WarningAction SilentlyContinue -ErrorAction SilentlyContinue

}else{

    Set-BrokerMachine -MachineName "CHILDRENS\APWCX164" -InMaintenanceMode $true -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
    [decimal]$yb = ($busrcnt-$balanced)
    $move = [math]::floor($yb)
    Add-Content C:\Log\rebalance-displayboards.txt -value "Move $move from APWCX164"
    $discusers = get-random -Count $move -InputObject $busers.Uid
    Add-Content C:\Log\rebalance-displayboards.txt -value "Users to be moved from APWCX164 are:"
            foreach ($user in $discusers) {
            Stop-BrokerSession -InputObject $user
            Add-Content C:\Log\rebalance-displayboards.txt -Value (Get-BrokerSession -uid $user | select -ExpandProperty UserName)
            }
    Start-sleep 120 #Wait for disconnected users to relogin
    Set-BrokerMachine -MachineName "CHILDRENS\APWCX164" -InMaintenanceMode $false -WarningAction SilentlyContinue -ErrorAction SilentlyContinue

}


Add-Content C:\Log\rebalance-displayboards.txt -value "Ending user counts:"
$ausrcntnew = (Get-BrokerSession -LaunchedViaPublishedName "Epic PRD Display Boards" -HostedMachineName "APWCX163").count
$busrcntnew = (Get-BrokerSession -LaunchedViaPublishedName "Epic PRD Display Boards" -HostedMachineName "APWCX164").count
Add-Content C:\Log\rebalance-displayboards.txt -value "$ausrcntnew on APWCX163"
Add-Content C:\Log\rebalance-displayboards.txt -value "$busrcntnew on APWCX164"
$finished = Get-Date -UFormat '%x %r %Z'
Add-Content C:\Log\rebalance-displayboards.txt -value "Completed rebalance at $finished"
Add-Content C:\Log\rebalance-displayboards.txt -value "------------------------------------------------------"
