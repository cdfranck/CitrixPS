﻿Asnp citrix*
$servername = Read-Host "Provide servers short name ie. apwcx126:"

Set-BrokerMachine -MachineName "CHILDRENS\$servername" -InMaintenanceMode $true

Get-BrokerSession -MachineName "CHILDRENS\$servername" -MaxRecordCount 500| Set-BrokerSession -Hidden $true

Write-host "Server: CHILDRENS\$servername has been placed in maintenance mode and existing sessions have been hidden from Studio & Director."

# Email reminder
$from = "APWCDDC01@seattle.childrens.org"
$subject = "$server in maintmode"
$sendto = "candi.franck@virtustream.com"
$body = "Please reboot $server and return to rotation."
$port = "25"
$smtpsvr = "email.seattlechildrens.org"
Send-MailMessage -From $from -Subject $subject -To $sendto -Body $body -Port $port -SmtpServer $smtpsvr

# RE: https://support.citrix.com/article/CTX217246