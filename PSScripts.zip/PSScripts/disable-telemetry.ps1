﻿Add-PSSnapin Citrix*

# Disable CEIP
New-ItemProperty -Path HKLM:\SOFTWARE\Citrix\Telemetry\CEIP -Name Enabled -PropertyType DWORD -Value 0
Stop-Service -InputObject CitrixVDACeipService -Force
Set-Service CitrixVDACeipService -StartupType Disabled

# Disable Citrix Call Home
Disable-CitrixCallHome
Enable-CitrixTrace -Listen‘{“trace”:{“enabled”:false,“persistDirectory”:“C:\Users\Public”,”maxSizeBytes”:1000000, “sliceDurationSeconds”:300}}’

# Disable AppV
Stop-Service -InputObject CtxAppVService -Force
Set-Service CtxAppVService -StartupType Disabled