﻿Add-PSSnapin citrix*
$groups = Get-BrokerApplicationGroup | select -ExpandProperty Name 

foreach ($group in $groups){

Set-BrokerApplicationGroup -Name $group -SessionSharingEnabled $false -SingleAppPerSession $true

}

Get-BrokerApplicationGroup |Select Name,SessionSharingEnabled,SingleAppPerSession

#RE: https://support.citrix.com/article/CTX232362
#  reset all on 10/21/2020 (cf)

<#--
Name                   SessionSharingEnabled SingleAppPerSession
----                   --------------------- -------------------
Display Board                          False                True
Epic Non-Prod A                        False                True
Epic Non-Prod B                        False                True
Epic Production                        False                True
Epic Training A                        False                True
Epic Training B                        False                True
Imprivata Test                         False                True
OnBase Troubleshooting                 False                True
Restricted Testing                     False                True
Willow Ambulatory A                    False                True
Willow Ambulatory B                    False                True
Willow Ambulatory Prod                 False                True

DR SITE
Name              SessionSharingEnabled SingleAppPerSession
----              --------------------- -------------------
Epic Production                   False                True
Willow Production                 False                True

--#>