﻿# Cleanup C Drive on Server

$server = $env:COMPUTERNAME
$timestamp = Get-Date -UFormat '%x %r %Z'

# Start cleanup.log
$freegb = Get-CimInstance -Class Win32_LogicalDisk |Where-Object {$_.DeviceID -eq "C:"}| Select-Object -ExpandProperty freespace
$before = ($freegb/1gb)
Add-Content -Path 'c:\scripts\cleanup.log' -Value "---------------------------------------------------"
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Cleanup started on $server on $timestamp."

# Remove user profiles older than 1 day
$precnt = (get-childitem -Directory C:\Users).count 
Get-WMIObject -class Win32_UserProfile | Where {(!$_.Special) -and ($_.ConvertToDateTime($_.LastUseTime) -lt (Get-Date).AddDays(-1))} | Remove-WmiObject
$pstcnt = (get-childitem -Directory C:\Users).count
$deleted = ($precnt-$pstcnt)
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Deleted $deleted profiles on $server."

# Clear event logs
$logs = Get-EventLog -List | ForEach-Object {$_.Log}
ForEach ($log in $logs) {Clear-EventLog -LogName $log}
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Event logs cleared on $server."

# Run Disk Cleanup (C;\)
start-process cleanmgr -ArgumentList "/d c /verylowdisk" -Wait
Read-Host -Prompt "Press any key to continue once the Disk Cleanup is completed..."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Disk cleanup performed on $server"

# Capture free disk after cleanup
$freenow = Get-CimInstance -Class Win32_LogicalDisk -ComputerName $server |Where-Object {$_.DeviceID -eq "C:"}| Select-Object -ExpandProperty freespace
$dfree = Get-CimInstance -Class Win32_LogicalDisk -ComputerName $server |Where-Object {$_.DeviceID -eq "D:"}| Select-Object -ExpandProperty freespace
$dfreegb = ($dfree/1gb)
$after = ($freenow/1gb)
$result = ($after-$before)

# Reset Perfmon Counters
Stop-Service brokeragent -force -PassThru 
lodctr.exe /r
lodctr.exe /r
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Reset Perfmon counters per CTX129350."
Start-Service brokeragent -PassThru
$broker = Get-Service BrokerAgent |Select -ExpandProperty Status
Add-Content -Path 'c:\scripts\cleanup.log' "Restarted BrokerAgent, Status: $broker"



# Log results
Add-Content -Path 'c:\scripts\cleanup.log' -Value "$result GB recovered on $server."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "$after GB (of 60GB) free on $server."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "$dfreegb GB (of 60GB) free write-cache for $server."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Cleanup completed on $server on $timestamp."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "---------------------------------------------------"

