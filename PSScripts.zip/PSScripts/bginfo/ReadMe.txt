1) Create C:\BGInfo 
2) Copy Set-Wallpaper.psm1 to the folder
3) Copy get-stats_v1.ps1 to the folder
4) Copy an appropriate JPG to the folder
5) Use preferred method to run C:\BGInfo\get-stats_v1.ps1 on start up