﻿Add-PSSnapin Citrix*

# High session count
Write-Host "Citrix PRD servers with higher than expected session count:" -ForegroundColor Red -BackgroundColor Yellow
Write-Host "_______________________________________________________"
write-host "(If empty, no records were found.)"
Write-host ""
Get-BrokerMachine -DesktopGroupName "Epic Production" | Where-Object {$_.SessionCount -gt 22} | Where-Object {$_.LoadIndex -gt 850} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize
Write-host ""



# Low session count
Write-Host "Citrix PRD servers with lower than expected session count:" -ForegroundColor Blue -BackgroundColor White
Write-Host "_______________________________________________________"
write-host "(If empty, no records were found.)"
Write-host ""
Get-BrokerMachine -DesktopGroupName "Epic Production" | Where-Object {$_.SessionCount -lt 2} | Where-Object {$_.LoadIndex -gt 80} | Select MachineName,SessionCount,LoadIndex |ft -AutoSize
Write-host ""



# Session count & load index for Prod
#Write-Host "Production session counts with current load:" -ForegroundColor Yellow -BackgroundColor Black
#Get-BrokerMachine -DesktopGroupName "Epic Production" | Select MachineName,SessionCount,LoadIndex |ft -AutoSize


# One user equals 40 load
Get-BrokerMachine -SessionCount 1 | Where-Object {$_.LoadIndex -gt 45} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize

# Two users equals 80 load
Get-BrokerMachine -SessionCount 2 | Where-Object {$_.LoadIndex -gt 85} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize

# Three users equals 120 load
Get-BrokerMachine -SessionCount 3 | Where-Object {$_.LoadIndex -gt 125} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize

# Four users equals 160 load
Get-BrokerMachine -SessionCount 4 | Where-Object {$_.LoadIndex -gt 165} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize

# Five users equals 200 load
Get-BrokerMachine -SessionCount 5 | Where-Object {$_.LoadIndex -gt 210} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize

# Ten users equals 400 load
Get-BrokerMachine -SessionCount 10 | Where-Object {$_.LoadIndex -gt 420} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize

# Fifteen users equals 640 load
Get-BrokerMachine -SessionCount 15 | Where-Object {$_.LoadIndex -gt 640} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize

# Twenty users equals 800 load
Get-BrokerMachine -SessionCount 20 | Where-Object {$_.LoadIndex -gt 850} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize

# Twenty-five users equals 1000 load
Get-BrokerMachine -SessionCount 25 | Where-Object {$_.LoadIndex -gt 1000} |Select MachineName,SessionCount,LoadIndex |ft -AutoSize