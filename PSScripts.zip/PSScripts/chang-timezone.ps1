﻿# Change Time Zone

# Read in a list of device names
$serverFile = 'C:\Temp\Servers.txt'
$tzId = "Pacific Standard Time"
    <#-- Options: 
    US Eastern Standard Time
    US Mountain Standard Time
    Pacific Standard Time
    Mountain Standard Time
    Central Standard Time --#>

# Perform the change for each device in list
foreach ($server in $serverFile) {

    # PSremote to server
    Enter-PSSession -ComputerName $server

    # Set Time Zone
    Set-TimeZone -Id $tzId

    # Report
    $newTz = Get-TimeZone |Select -ExpandProperty Id
    Write-Host $server 'new timezone is ' $newTz

    # Close PSsession
    Exit-PSSession    

}

