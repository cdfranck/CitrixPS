﻿CLEAR

$allenv = (Get-BrokerSession -SessionState Active -AppState Active -MaxRecordCount 5000| select UntrustedUserName -Unique).count

write-host "All active users, all environments: $allenv"

$alldis = (Get-BrokerSession -SessionState Disconnected -MaxRecordCount 5000| select UntrustedUserName -Unique).count

write-host "All disconnected users, all environments: $alldis"

$unique = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Active -AppState Active -MaxRecordCount 5000| select UntrustedUserName -Unique).count

write-host "All Prod UNIQUE users: $unique"

$allusers = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Active -AppState Active -MaxRecordCount 5000| select UntrustedUserName).count

write-host "All Prod users: $allusers"

$timestamp = get-date -DisplayHint DateTime

$dupes = ($allusers-$unique)

write-host "Duplicate users in Prod as of $timestamp : $dupes"


