﻿#Get REL Location

Get-BrokerApplication -ApplicationName "Epic REL" | Select ApplicationName,CommandLineExecutable,CommandLineArguments,WorkingDirectory | Format-List
Get-BrokerApplication -ApplicationName "Epic REL Alaska" | Select ApplicationName,CommandLineExecutable,CommandLineArguments,WorkingDirectory | Format-List
Get-BrokerApplication -ApplicationName "Epic REL Montana" | Select ApplicationName,CommandLineExecutable,CommandLineArguments,WorkingDirectory | Format-List
Get-BrokerApplication -ApplicationName "Epic REL WarpDrive" | Select ApplicationName,CommandLineExecutable,CommandLineArguments,WorkingDirectory | Format-List
