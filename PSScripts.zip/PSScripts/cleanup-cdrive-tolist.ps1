﻿# Cleanup C Drive on Server

$servers = ('apwcx063','atwcx017')
$timestamp = Get-Date -UFormat '%x %r %Z'
#$sec = Get-Credential


foreach ($server in $servers){
# Capture free disk before cleanup
$freegb = Get-CimInstance -Class Win32_LogicalDisk -ComputerName $server |Where-Object {$_.DeviceID -eq "C:"}| Select-Object -ExpandProperty freespace
$before = ($freegb/1gb)

# Log start
Add-Content -Path '\\atwnas01\dumptruck\Citrix\cleanup.log' -Value "Cleanup started on $server on $timestamp."

# Cleanup user profiles
$precnt = (get-childitem -Directory "\\$server\C$\Users").count
Get-WMIObject -class Win32_UserProfile -ComputerName $server | Where {(!$_.Special) -and ($_.ConvertToDateTime($_.LastUseTime) -lt (Get-Date).AddDays(-1))} | Remove-WmiObject
$pstcnt = (get-childitem -Directory "\\$server\C$\Users").count
$deleted = ($precnt-$pstcnt)
Add-Content -Path \\atwnas01\dumptruck\Citrix\cleanup.log -Value "Deleted $deleted profiles on $server."

# Clear event logs
Invoke-Command -ComputerName $server -ScriptBlock {
$logs = Get-EventLog -List | ForEach-Object {$_.Log}
ForEach ($log in $logs) {Clear-EventLog -LogName $log}
}
Add-Content -Path '\\atwnas01\dumptruck\Citrix\cleanup.log' -Value "Event logs cleared on $server."

# PSremote to server
Enter-PSSession -ComputerName $server
# Run disk cleanup
Invoke-Command -ComputerName $server -AsJob -ScriptBlock {
start-process cleanmgr -ArgumentList "/d c /verylowdisk" -Wait -NoNewWindow -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -InformationAction SilentlyContinue
}
# cannot figure out how to make this run silently so waiting five minutes then killing the process which I believe by that time will only be ending the summary pop-up showing how much was deleted
Start-Sleep 300
get-process cleanmgr | Stop-Process -Force
# PSremote to server
Exit-PSSession
Add-Content -Path '\\atwnas01\dumptruck\Citrix\cleanup.log' -Value "Disk cleanup performed on $server."

# Capture free disk after cleanup
$freenow = Get-CimInstance -Class Win32_LogicalDisk -ComputerName $server |Where-Object {$_.DeviceID -eq "C:"}| Select-Object -ExpandProperty freespace
$dfree = Get-CimInstance -Class Win32_LogicalDisk -ComputerName $server |Where-Object {$_.DeviceID -eq "D:"}| Select-Object -ExpandProperty freespace
$after = ($freenow/1gb)
$result = ($after-$before)

# Log results
Add-Content -Path '\\atwnas01\dumptruck\Citrix\cleanup.log' -Value "$result GB recovered on $server."
Add-Content -Path '\\atwnas01\dumptruck\Citrix\cleanup.log' -Value "$freenow GB (of 60GB) free on $server."
Add-Content -Path '\\atwnas01\dumptruck\Citrix\cleanup.log' -Value "$dfree GB (of 60GB) free write-cache for $server."
Add-Content -Path '\\atwnas01\dumptruck\Citrix\cleanup.log' -Value "---------------------------------"

}