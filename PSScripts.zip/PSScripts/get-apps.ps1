﻿get-brokerapplication | select PublishedName,CommandLineExecutable,Enabled,MaxPerUserInstances,MaxTotalInstances | ft -AutoSize | Out-File C:\TEMP\applist.txt -Append

get-brokerapplicationgroup | select name,SessionSharingEnabled,SingleAppPerSession | ft -AutoSize | Out-File C:\TEMP\applist.txt -Append