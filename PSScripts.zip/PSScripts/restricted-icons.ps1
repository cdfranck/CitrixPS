﻿Get-BrokerApplication -AdminFolderName Restricted\ |Select PublishedName,Enabled,Visible



Set-BrokerApplication -Name "Restricted\Command Prompt" -Enabled $false -Visible $false
Set-BrokerApplication -Name "Restricted\Epic POC May2020 - Restricted Testing" -Enabled $false -Visible $false
Set-BrokerApplication -Name "Restricted\Epic POC Universal Launcher" -Enabled $false -Visible $false
Set-BrokerApplication -Name "Restricted\Epic POC WarpDrive - Restricted Testing" -Enabled $false -Visible $false
Set-BrokerApplication -Name "Restricted\Epic PRD May2020 - Restricted Testing" -Enabled $false -Visible $false
Set-BrokerApplication -Name "Restricted\Epic REL May2020 - Restricted Testing" -Enabled $false -Visible $false
Set-BrokerApplication -Name "Restricted\Epic TST May2020 - Restricted Testing" -Enabled $false -Visible $false


Set-BrokerApplication -Name "Restricted\Command Prompt" -Enabled $true -Visible $false
Set-BrokerApplication -Name "Restricted\Epic POC May2020 - Restricted Testing" -Enabled $true -Visible $false
Set-BrokerApplication -Name "Restricted\Epic POC Universal Launcher" -Enabled $true -Visible $false
Set-BrokerApplication -Name "Restricted\Epic POC WarpDrive - Restricted Testing" -Enabled $true -Visible $false
Set-BrokerApplication -Name "Restricted\Epic PRD May2020 - Restricted Testing" -Enabled $true -Visible $false
Set-BrokerApplication -Name "Restricted\Epic REL May2020 - Restricted Testing" -Enabled $true -Visible $false
Set-BrokerApplication -Name "Restricted\Epic TST May2020 - Restricted Testing" -Enabled $true -Visible $false