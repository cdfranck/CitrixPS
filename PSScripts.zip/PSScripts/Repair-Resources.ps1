﻿# Cleanup C Drive on Server

$server = $env:COMPUTERNAME
$timestamp = Get-Date -UFormat '%x %r %Z'

# Start cleanup.log
$freegb = Get-CimInstance -Class Win32_LogicalDisk |Where-Object {$_.DeviceID -eq "C:"}| Select-Object -ExpandProperty freespace
$before = ($freegb/1gb)
Add-Content -Path 'c:\scripts\cleanup.log' -Value "---------------------------------------------------"
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Cleanup started on $server on $timestamp."

# Remove user profiles older than 1 day
$precnt = (get-childitem -Directory C:\Users).count 
Get-WMIObject -class Win32_UserProfile | Where {(!$_.Special) -and ($_.ConvertToDateTime($_.LastUseTime) -lt (Get-Date).AddDays(-1))} | Remove-WmiObject
$pstcnt = (get-childitem -Directory C:\Users).count
$deleted = ($precnt-$pstcnt)
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Deleted $deleted profiles on $server."

# Run Disk Cleanup (C;\)
start-process cleanmgr -ArgumentList "/d c /verylowdisk" -Wait
Read-Host -Prompt "You may want to re-run Disk Cleanup for System Files."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Disk cleanup performed on $server"

# Cleanup System Files 
#$modsinst = Get-Service TrustedInstaller | Select -ExpandProperty Status
#If ($modsinst = "Running") {Stop-Service TrustedInstaller -Force}
#Remove-Item -Path C:\Windows\Logs\CBS\*.log -force
#Remove-Item -Path C:\Windows\Temp\*.* -Recurse -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

# Reset Perfmon Counters
Stop-Service brokeragent -force -PassThru 
lodctr.exe /R
lodctr.exe /R
winmgmt.exe /RESYNCPERF
winmgmt.exe /RESYNCPERF
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Reset Perfmon counters per CTX129350."
Start-Service brokeragent -PassThru
$broker = Get-Service BrokerAgent |Select -ExpandProperty Status
Add-Content -Path 'c:\scripts\cleanup.log' -value "Restarted BrokerAgent, Status: $broker"

# Empty Recycle Bin
Clear-RecycleBin -Force
Add-Content -Path 'c:\scripts\cleanup.log' -value "Emptied Recycle Bin."

# Capture free disk after cleanup
$freenow = Get-CimInstance -Class Win32_LogicalDisk -ComputerName $server |Where-Object {$_.DeviceID -eq "C:"}| Select-Object -ExpandProperty freespace
$dfree = Get-CimInstance -Class Win32_LogicalDisk -ComputerName $server |Where-Object {$_.DeviceID -eq "D:"}| Select-Object -ExpandProperty freespace
$dfreegb = ($dfree/1gb)
$after = ($freenow/1gb)
$result = ($after-$before)

# Clear event logs
$logs = Get-EventLog -List | ForEach-Object {$_.Log}
ForEach ($log in $logs) {Clear-EventLog -LogName $log}
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Event logs cleared on $server."

# Log results
Add-Content -Path 'c:\scripts\cleanup.log' -Value "$result GB recovered on $server."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "$after GB (of 60GB) free on $server."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "$dfreegb GB (of 60GB) free write-cache for $server."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "Cleanup completed on $server on $timestamp."
Add-Content -Path 'c:\scripts\cleanup.log' -Value "---------------------------------------------------"

Add-Content -Path "\\atwnas01\dumptruck\citrix\Running-Cleanup.log" -value (Get-Content 'c:\scripts\cleanup.log')
start-sleep 15
remove-item 'c:\scripts\cleanup.log'
exit