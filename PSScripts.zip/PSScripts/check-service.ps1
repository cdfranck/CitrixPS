﻿Add-PSSnapin citrix*
Set-ExecutionPolicy Unrestricted

Get-BrokerMachine |select -ExpandProperty DNSNAME | Out-File C:\scripts\servers.txt
$servers = Get-Content C:\scripts\servers.txt


foreach ($server in $servers) {
get-service -computername $server -name SSOManHost64
}