﻿Add-PSSnapin citrix*

#Generate report header
$start=get-date -UFormat "%x %r"
Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "Current Change of Imprivata registry key"
Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value $start
Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "----------------------------------------"

# Set registry variables (in case we want to add a section to remediate later)
#$appliancepath = "HKLM:\SOFTWARE\WOW6432Node\SSOProvider\ISXAgent\"
#$appliancekey = "IPTXPrimServer"
#$prodappliance = "https://PPXIMP02.childrens.sea.kids/sso/servlet/messagerouter"
#$testappliance = "https://PTXIMP01.childrens.sea.kids/sso/servlet/messagerouter"

# Change Prod Imprivata RegKey
Get-BrokerMachine -MachineName "CHILDRENS\APWCX*" | Select -ExpandProperty DNSname | Out-File C:\scripts\prodservers.txt
$prodservers = Get-Content C:\scripts\prodservers.txt

foreach ($server in $prodservers) {

$Session = New-PSSession -ComputerName $server

#Check key value
$appliance = Invoke-Command -Session $Session -ScriptBlock {
    (Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\SSOProvider\ISXAgent\").IPTXPrimServer
    }

#Report key value
if($appliance = "https://PPXIMP02.childrens.sea.kids/sso/servlet/messagerouter") {
   Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "$server is using PPXIMP02 (Prod)"
}elseif($appliance = "https://PTXIMP01.childrens.sea.kids/sso/servlet/messagerouter") {
   Invoke-Command -Session $Session -ScriptBlock {
    (Set-ItemProperty -Value "https://PTXIMP01.childrens.sea.kids/sso/servlet/messagerouter" -Path "HKLM:\SOFTWARE\WOW6432Node\SSOProvider\ISXAgent\").IPTXPrimServer
    }
   Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "$server has been updated"
}else {
   Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value  "Could not read key for $server"
}

Remove-PSSession $Session  

}

<#
# Check Test Imprivata RegKey
Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "Start Test review"
Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "----------------------------------------"

Get-BrokerMachine -MachineName "CHILDRENS\ATWCX*" | Select -ExpandProperty DNSname | Out-File C:\scripts\testservers.txt
$testservers = Get-Command C:\scripts\testservers.txt

foreach ($server in $testservers) {

$Session = New-PSSession -ComputerName $server

#Check key value
$appliance = Invoke-Command -Session $Session -ScriptBlock {
    (Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\SSOProvider\ISXAgent\").IPTXPrimServer
    }

#Report key value
if($appliance = "https://PPXIMP02.childrens.sea.kids/sso/servlet/messagerouter") {
   Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "$server is using PPXIMP02 (Prod)"
}elseif($appliance = "https://PTXIMP01.childrens.sea.kids/sso/servlet/messagerouter") {
   Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "$server is using PTXIMP01 (Test)"
}else {
   Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value  "Could not read key for $server"
}

Remove-PSSession $Session   

}
#>

#Generate report footer
$end=get-date -UFormat "%x %r"
Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "----------------------------------------"
Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value "Report completed"
Add-Content -Path \\atwnas01\DumpTruck\Citrix\ImprivataChange.txt -Value $end





