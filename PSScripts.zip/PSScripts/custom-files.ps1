﻿#update custom files

#ABN file
#Copy-Item '\\atwnas01\software$\Presentation\Epic\HTML_files\AC2017CMSR131ABN.htm' "C:\Program Files (x86)\Epic\v9.1\en-US\HTML\AC2017CMSR131ABN.htm" -Force
Copy-Item '\\atwnas01\software$\Presentation\Epic\HTML_files\AC2017CMSR131ABN.htm' "C:\Program Files (x86)\Epic\v9.3\en-US\HTML\AC2017CMSR131ABN.htm" -Force

#Special Chart Request
#Copy-Item '\\atwnas01\software$\Presentation\Epic\SLG5176504_Special-Chart-Request\CHISEASpecialRequest91.ocx' "C:\Program Files (x86)\Epic\v9.1\Shared Files\" -Force
Copy-Item '\\atwnas01\software$\Presentation\Epic\SLG5176504_Special-Chart-Request\CHISEASpecialRequest93.ocx' "C:\Program Files (x86)\Epic\v9.3\Shared Files\" -Force