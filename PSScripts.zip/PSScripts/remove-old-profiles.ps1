﻿#remove old profiles from single server
(Get-WMIObject -class Win32_UserProfile | Where {(!$_.Special) -and ($_.ConvertToDateTime($_.LastUseTime) -lt (Get-Date).AddDays(-1))}).count
Get-WMIObject -class Win32_UserProfile | Where {(!$_.Special) -and ($_.ConvertToDateTime($_.LastUseTime) -lt (Get-Date).AddDays(-1))} | Remove-WmiObject


#clear event logs
$logs = Get-EventLog -List | ForEach-Object {$_.Log}
ForEach ($log in $logs) {Clear-EventLog -LogName $log}
Get-EventLog -List

start-process cleanmgr -ArgumentList "/d c: /verylowdisk" -Wait -NoNewWindow -ErrorAction SilentlyContinue -WarningAction SilentlyContinue