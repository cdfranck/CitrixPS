﻿#Disable CEIP
New-ItemProperty -Name Enabled -Path HKLM:\SOFTWARE\Citrix\Telemetry\CEIP -Force -PropertyType DWORD -Value 0
Stop-Service -InputObject CitrixVDACeipService -Force
Set-Service CitrixVDACeipService -StartupType Disabled

#Disable AppV
Stop-Service -InputObject CtxAppVService -Force
Set-Service CtxAppVService -StartupType Disabled