﻿# Willow Ambulatorty Entitelment & Leasing Behavior
Add-PSSnapin Citrix*

# Session Reconnection Options
# "Always"
# Sessions always roam, regardless of the client device and whether the session is connected or disconnected. This is the default value.
# Requires that Leasing Behavior is set to Disallowed
# "DisconnectedOnly"
# Reconnect only to sessions that are already disconnected; otherwise, launch a new session. (Sessions can roam between client devices by first disconnecting them, or using Workspace Control to explicitly roam them.) 
# An active connected session from another client device is never used; instead, a new session is launched.
# Requires that Leasing Behavior is set to Allowed
# "SameEndpointOnly"
# A user gets a unique session for each client device they use. This completely disables roaming. Users can reconnect only to the same device that was previously used in the session.
# Requires that Leasing Behavior is set to Allowed


# Set Willow A
Set-BrokerAppEntitlementPolicyRule "Willow Ambulatory" -SessionReconnection SameEndpointOnly -LeasingBehavior Allowed
#undo
Set-BrokerAppEntitlementPolicyRule "Willow Ambulatory" -SessionReconnection Always -LeasingBehavior Allowed

# Set Willow B
Set-BrokerAppEntitlementPolicyRule "Willow Ambulatory B" -SessionReconnection SameEndpointOnly -LeasingBehavior Allowed
#undo
Set-BrokerAppEntitlementPolicyRule "Willow Ambulatory B" -SessionReconnection Always -LeasingBehavior Allowed

# Set Willow Prod
Set-BrokerAppEntitlementPolicyRule "Willow Ambulatory Prod" -SessionReconnection SameEndpointOnly -LeasingBehavior Allowed
#undo
Set-BrokerAppEntitlementPolicyRule "Willow Ambulatory Prod" -SessionReconnection Always -LeasingBehavior Allowed