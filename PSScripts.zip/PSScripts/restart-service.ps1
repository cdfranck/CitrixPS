﻿Add-PSSnapin citrix*
Set-ExecutionPolicy Unrestricted

Get-BrokerMachine |select -ExpandProperty DNSNAME | Out-File C:\scripts\servers.txt
$servers = Get-Content C:\scripts\servers.txt


foreach ($server in $servers) {
#Invoke-Command -AsJob $server -ScriptBlock {Stop-Service SSOManHost64 -force}
Invoke-Command -AsJob $server -ScriptBlock {Start-Service SSOManHost64}
}