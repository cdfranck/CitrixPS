﻿$serverlist = Get-Content C:\scripts\sundayservers.txt

foreach ($server in $serverlist) {
    Get-CimInstance -ClassName win32_operatingsystem -ComputerName "$server" | select csname,lastbootuptime | Sort-Object lastbootuptime
}
