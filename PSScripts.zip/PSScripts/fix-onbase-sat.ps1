﻿
$servers = get-content "\\atwnas01\software$\Presentation\PSScripts\ServerReboots\SaturdayServers.txt"

Foreach ($server in $servers){

$session = New-PSSession -ComputerName $server

Enter-Pssession $session

$onbase = "HKLM:\SOFTWARE\WOW6432Node\Hyland\Front Office Scanning"

Set-ItemProperty -Path $onbase -Name EpicConfigFile -Value "\\APWNAS\ONBASE$\EPICFOSCONFIG.XML"

Copy-Item C:\Scripts\OnBasePRD\OnBaseEpicWeb.config 'C:\Program Files (x86)\Common Files\Epic\Interfaces\OnBaseEpic.Web.config' -Force

Remove-PSSession $session
}