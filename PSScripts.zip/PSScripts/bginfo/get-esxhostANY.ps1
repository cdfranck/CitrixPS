﻿#environment specific variables
$deliverycontroller = "APWCDDC02.childrens.sea.kids"
$remotedomain = "CHILDRENS"

#guest-vda commands
$server = $env:COMPUTERNAME
$session = New-PSSession -ComputerName $deliverycontroller

Invoke-Command -Session $session -ScriptBlock {
    Add-PSSnapin Citrix*
    $domain = $using:remotedomain
    $guest = $using:server
    $esxhost = Get-BrokerMachine -MachineName "$domain\$guest" | Select -ExpandProperty HostingServerName
    Add-content -Path "C:\temp\$guest.txt" -Value "$guest is on $esxhost" -Force
}

Move-Item "\\$deliverycontroller\c$\temp\$server.txt" "c:\tools\bginfo\esxhost.txt" -Force 

exit



