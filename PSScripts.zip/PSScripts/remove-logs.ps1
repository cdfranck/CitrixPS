#Script to cleanup logs when the image is updated 

# Delete imprivata logs
Remove-Item -Path "C:\ProgramData\SSOProvider\Logs\*.*" -Force

# Delete optimizer logs
Remove-Item -Path "C:\Tools\CitrixOptimizer\Logs\*" -Force -Recurse

# Delete epic logs
Remove-item -Path "C:\Tools\Epic.Support.v6.3.3\Output\*" -Force -Recurse

# Empty Recycle Bin
Clear-RecycleBin -Force -Confirm:$false
