﻿<# Info
Name                                    AllAssociatedDesktopGroupUids
----                                    -----------------------------
Prod\Epic PRD                           {2}                                                  
Prod\Epic PRD AL Warp                   {2}                          
Prod\Epic PRD MN Warp                   {2}                          
Prod\Epic PRD WarpDrive                 {2}                                                
Prod\Epic Read-Only                     {2}                          
Prod\Epic SHD WarpDrive                 {2}                             

Name                Uid
----                ---
Epic Non-Prod A       1
Epic Non-Prod B       5
Epic Prod - Coders    9
Epic Prod-Standby     8
Epic Production       2
Epic Training A       3
Epic Training B       7
Mmodal POC           11
Willow Ambulatory     4
Willow Ambulatory B   6                    
#>

# Put Prod servers in mm\make sure standby are avail
Set-BrokerDesktopGroup -InputObject 2 -InMaintenanceMode $true
Set-BrokerDesktopGroup -InputObject 8 -InMaintenanceMode $false

# Move Prod apps to use the Standby servers
Add-BrokerApplication -Name "Prod\Epic PRD" -DesktopGroup "Epic Prod-Standby"
Add-BrokerApplication -Name "Prod\Epic PRD AL Warp" -DesktopGroup "Epic Prod-Standby"
Add-BrokerApplication -Name "Prod\Epic PRD MN Warp" -DesktopGroup "Epic Prod-Standby"
Add-BrokerApplication -Name "Prod\Epic PRD WarpDrive" -DesktopGroup "Epic Prod-Standby"
Add-BrokerApplication -Name "Prod\Epic Read-Only" -DesktopGroup "Epic Prod-Standby"
Add-BrokerApplication -Name "Prod\Epic SHD WarpDrive" -DesktopGroup "Epic Prod-Standby"

Remove-BrokerApplication -Name "Prod\Epic PRD" -DesktopGroup "Epic Production"
Remove-BrokerApplication -Name "Prod\Epic PRD AL Warp" -DesktopGroup "Epic Production"
Remove-BrokerApplication -Name "Prod\Epic PRD MN Warp" -DesktopGroup "Epic Production"
Remove-BrokerApplication -Name "Prod\Epic PRD WarpDrive" -DesktopGroup "Epic Production"
Remove-BrokerApplication -Name "Prod\Epic Read-Only" -DesktopGroup "Epic Production"
Remove-BrokerApplication -Name "Prod\Epic SHD WarpDrive" -DesktopGroup "Epic Production"

# Check delivery groups -- Should be only [8]
Get-BrokerApplication -AdminFolderName "Prod\" | Select Name,AllAssociatedDesktopGroupUids

# Put Standby servers in mm\make sure Prod are avail
Set-BrokerDesktopGroup -InputObject 8 -InMaintenanceMode $true
Set-BrokerDesktopGroup -InputObject 2 -InMaintenanceMode $false

# Move Prod apps back to the Prod servers
Add-BrokerApplication -Name "Prod\Epic PRD" -DesktopGroup "Epic Prod-Standby"
Add-BrokerApplication -Name "Prod\Epic PRD AL Warp" -DesktopGroup "Epic Production"
Add-BrokerApplication -Name "Prod\Epic PRD MN Warp" -DesktopGroup "Epic Production"
Add-BrokerApplication -Name "Prod\Epic PRD WarpDrive" -DesktopGroup "Epic Production"
Add-BrokerApplication -Name "Prod\Epic Read-Only" -DesktopGroup "Epic Production"
Add-BrokerApplication -Name "Prod\Epic SHD WarpDrive" -DesktopGroup "Epic Production"

Remove-BrokerApplication -Name "Prod\Epic PRD" -DesktopGroup "Epic Prod-Standby"
Remove-BrokerApplication -Name "Prod\Epic PRD AL Warp" -DesktopGroup "Epic Prod-Standby"
Remove-BrokerApplication -Name "Prod\Epic PRD MN Warp" -DesktopGroup "Epic Prod-Standby"
Remove-BrokerApplication -Name "Prod\Epic PRD WarpDrive" -DesktopGroup "Epic Prod-Standby"
Remove-BrokerApplication -Name "Prod\Epic Read-Only" -DesktopGroup "Epic Prod-Standby"
Remove-BrokerApplication -Name "Prod\Epic SHD WarpDrive" -DesktopGroup "Epic Prod-Standby"

# Check delivery groups -- Should be only [2]
Get-BrokerApplication -AdminFolderName "Prod\" | Select Name,AllAssociatedDesktopGroupUids