﻿Add-PSSnapin citrix*

#Get stale disconnected sessions
$disconnectlimit = (Get-Date).AddHours(-1)
Get-BrokerSession -SessionState Disconnected |Where-Object {$_.SessionStateChangeTime -lt $disconnectLimit}| Select UserName,MachineName,SessionStateChangeTime,BrokeringTime