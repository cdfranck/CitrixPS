Add-PSSnapin Citrix*

Set-ExecutionPolicy Unrestricted -Force

$grplist = 'Epic Non-Prod A','Epic Non-Prod B','Epic Production','Epic Training A','Epic Training B','Restricted Testing','Willow Ambulatory A','Willow Ambulatory B'

Get-BrokerMachine -AdminAddress APWCDDC01.childrens.sea.kids -PowerState 'off' -Filter { DesktopGroupName -in $grplist } -Property MachineName | New-BrokerHostingPowerAction -action TurnOn