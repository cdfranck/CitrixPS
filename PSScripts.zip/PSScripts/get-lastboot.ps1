﻿$saturday = Get-Content C:\scripts\saturdayservers.txt

foreach ($server in $saturday) {
    Get-CimInstance -ClassName win32_operatingsystem -ComputerName "$server" | select csname,lastbootuptime
}
