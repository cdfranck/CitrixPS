﻿Set-ExecutionPolicy Unrestricted
Enable-PSRemoting

$Computers = Get-Content '\\atwnas01\software$\Presentation\PSScripts\drservers.txt'


foreach ($computer in $computers) {
Invoke-Command -AsJob $computer -ScriptBlock {$path = "HKLM:\SOFTWARE\Policies\Citrix\VirtualDesktopAgent";Set-ItemProperty -Path $path -Name “ListOfDDCs” -Value "apwcddc21.childrens.sea.kids apwcddc22.childrens.sea.kids"}
}
