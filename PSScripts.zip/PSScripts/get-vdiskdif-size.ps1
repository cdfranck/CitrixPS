﻿Add-PSSnapin citrix*
Get-BrokerMachine | Select -ExpandProperty DNSNAME | Out-File C:\TEMP\servers.txt
$servers = get-content C:\temp\servers.txt

foreach ($server in $servers) {
$size = (Get-Item "\\$server\d$\vdiskdif.vhdx").Length
if ($size -gt 15GB){
write-host $server vdiskdif.vhdx is ($size/1GB) GB}else{
write-host $server vdiskdif.vhdx is under 15GB
}
}
