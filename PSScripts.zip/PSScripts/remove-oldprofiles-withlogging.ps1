﻿# Remove user profiles older than 1 day
$timestamp = Get-Date -UFormat '%x %r %Z'
$precnt = (get-childitem -Directory C:\Users).count 
Get-WMIObject -class Win32_UserProfile | Where {(!$_.Special) -and ($_.ConvertToDateTime($_.LastUseTime) -lt (Get-Date).AddDays(-1))} | Remove-WmiObject
$pstcnt = (get-childitem -Directory C:\Users).count
$deleted = ($precnt-$pstcnt)

Write-EventLog -LogName Application -Source "Powershell" -EntryType Information -EventId 201 -Category  -Message "Scheduled script removed $deleted old profiles on $server at $timestamp."