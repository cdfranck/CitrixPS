﻿Add-PSSnapin Citrix*

$serverlist = get-brokermachine | select -ExpandProperty dnsname

foreach ($server in $serverlist) {
    #Get-CimInstance -ClassName win32_operatingsystem -ComputerName "$server" | Select lastbootuptime
    Get-CimInstance -ClassName win32_operatingsystem -ComputerName "$server" | where {((!$_.LastBootUpTime) -lt (Get-Date).AddDays(-1))} | Select csname,lastbootuptime
}





