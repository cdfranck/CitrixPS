﻿qwinsta
start-process "\\atwnas01\software$\Presentation\Citrix\Health\procexp\procexp64.exe"