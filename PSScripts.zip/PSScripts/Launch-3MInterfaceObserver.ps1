﻿  <#
    .SYNOPSIS
      Launches 3M Interface Observer and Hyperspace in the same session.
    .EXAMPLE
     Launch-3MInterfaceObserver ENV″
     This command will open Hyperspace (using the Universal Launcher) to the environment ID specified and simultaneously launch Barcodifier.
  #>

$HypEnv=$args[0]

Start-Process 'C:\3mhis\connections\users\interface\Interface\Observer.exe'
start-process 'C:\Program Files (x86)\Epic\Hyperspace\EpicDesktop.exe' -ArgumentList "ENV=$HypEnv"
exit