﻿# Script to set reboot schedules for existing delivery groups to a 7-day rotation

# add snapin
Add-PSSnapin Citrix

# ************************************************************************************************************
# Servers must be tagged and in a scheduled delivery group for the reboot schedules to take effect.
# This script must be run for each new delivery group.
# There will be 7 schedules created per delivery group. 
# ---------->>> TAGS <<<----------|---------->>> Servers <<<----------|---------->>> Day-Time <<<----------
# SundayReboot_0-9                 Servers ending with 0 or 9           Sunday 2:15AM PST Start
# MondayReboot_1                   Servers ending with 1                Monday 2:15AM PST Start
# TuesdayReboot_2                  Servers ending with 2                Tuesday 2:15AM PST Start
# WednesdayReboot_3                Servers ending with 3                Wednesday 2:15AM PST Start
# ThursdayReboot_4	               Servers ending with 4                Thursday 2:15AM PST Start
# FridayReboot_5-6                 Servers ending with 5 or 6           Friday 2:15AM PST Start
# SaturdayReboot_7-8               Servers ending with 7 or 8           Saturday 2:15AM PST Start
# ************************************************************************************************************"

$deliveryGroups = ('Epic Non-Prod A','Epic Non-Prod B','Epic Production','Epic Training A','Epic Training B','Restricted Testing','Willow Ambulatory A','Willow Ambulatory B','Willow Ambulatory Prod')
# The 'Display Board' delivery group has its reboots scheduled in task manager on APWDCC01 using a powershell script instead of the cmdlet used here.
# DisplayBoard APWCX0164 Sat 2:05AM PST (every other week) -- Task Name: Reboot Display Boards Sat-Even (on APWCDDC01)
# DisplayBoard APWCX0163 Sun 2:05AM PST (every other week) -- Task Name: Reboot Display Boards Sun-Odd (on APWCDDC01)
# Re-balance runs every Sun at 4AM -- this force logs off some users sending them to the empty server -- Task Name:  Re-balance Display Board Users (on APWCDDC01)

# Remove any old schedules
foreach ($group in $deliveryGroups) {

Get-BrokerRebootScheduleV2 -DesktopGroupName $group | Remove-BrokerRebootScheduleV2 -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
Write-host "The next line should produce no data for $group."
Get-BrokerRebootScheduleV2 -DesktopGroupName $group | FT -AutoSize

}


# Create Schedules
foreach ($group in $deliveryGroups) {

# Create SUNDAY schedules
New-BrokerRebootScheduleV2 -Name "$group SundayReboot_0-9 Schedule" -DesktopGroupName $group -Day Sunday -Frequency Weekly -StartTime "2:15" -RebootDuration 120 -RestrictToTag SundayReboot_0-9 -WarningDuration 30 -WarningRepeatInterval 10 -WarningMessage "This server will be restarted in %m% minutes for weekly maintenance. Please save your work and logoff. You may logon again immediately. Thank You." -WarningTitle "Notice: Weekly Scheduled Reboot!" -Enabled $true -ErrorAction SilentlyContinue

# Create MONDAY schedules
New-BrokerRebootScheduleV2 -Name "$group MondayReboot_1 Schedule" -DesktopGroupName $group -Day Monday -Frequency Weekly -StartTime "2:15" -RebootDuration 120 -RestrictToTag MondayReboot_1 -WarningDuration 30 -WarningRepeatInterval 10 -WarningMessage "This server will be restarted in %m% minutes for weekly maintenance. Please save your work and logoff. You may logon again immediately. Thank You." -WarningTitle "Notice: Weekly Scheduled Reboot!" -Enabled $true -ErrorAction SilentlyContinue

# Create TUESDAY schedules
New-BrokerRebootScheduleV2 -Name "$group TuesdayReboot_2 Schedule" -DesktopGroupName $group -Day Tuesday -Frequency Weekly -StartTime "2:15" -RebootDuration 120 -RestrictToTag TuesdayReboot_2 -WarningDuration 30 -WarningRepeatInterval 10 -WarningMessage "This server will be restarted in %m% minutes for weekly maintenance. Please save your work and logoff. You may logon again immediately. Thank You." -WarningTitle "Notice: Weekly Scheduled Reboot!" -Enabled $true -ErrorAction SilentlyContinue

# Create WEDNESDAY schedules
New-BrokerRebootScheduleV2 -Name "$group WednesdayReboot_3 Schedule" -DesktopGroupName $group -Day Wednesday -Frequency Weekly -StartTime "2:15" -RebootDuration 120 -RestrictToTag WednesdayReboot_3 -WarningDuration 30 -WarningRepeatInterval 10 -WarningMessage "This server will be restarted in %m% minutes for weekly maintenance. Please save your work and logoff. You may logon again immediately. Thank You." -WarningTitle "Notice: Weekly Scheduled Reboot!" -Enabled $true -ErrorAction SilentlyContinue

# Create THURSDAY schedules
New-BrokerRebootScheduleV2 -Name "$group ThursdayReboot_4 Schedule" -DesktopGroupName $group -Day Thursday -Frequency Weekly -StartTime "2:15" -RebootDuration 120 -RestrictToTag ThursdayReboot_4 -WarningDuration 30 -WarningRepeatInterval 10 -WarningMessage "This server will be restarted in %m% minutes for weekly maintenance. Please save your work and logoff. You may logon again immediately. Thank You." -WarningTitle "Notice: Weekly Scheduled Reboot!" -Enabled $true -ErrorAction SilentlyContinue

# Create FRIDAY schedules
New-BrokerRebootScheduleV2 -Name "$group FridayReboot_5-6 Schedule" -DesktopGroupName $group -Day Friday -Frequency Weekly -StartTime "2:15" -RebootDuration 120 -RestrictToTag FridayReboot_5-6 -WarningDuration 30 -WarningRepeatInterval 10 -WarningMessage "This server will be restarted in %m% minutes for weekly maintenance. Please save your work and logoff. You may logon again immediately. Thank You." -WarningTitle "Notice: Weekly Scheduled Reboot!" -Enabled $true -ErrorAction SilentlyContinue

# Create SATURDAY schedules
New-BrokerRebootScheduleV2 -Name "$group SaturdayReboot_7-8 Schedule" -DesktopGroupName $group -Day Saturday -Frequency Weekly -StartTime "2:15" -RebootDuration 120 -RestrictToTag SaturdayReboot_7-8 -WarningDuration 30 -WarningRepeatInterval 10 -WarningMessage "This server will be restarted in %m% minutes for weekly maintenance. Please save your work and logoff. You may logon again immediately. Thank You." -WarningTitle "Notice: Weekly Scheduled Reboot!" -Enabled $true -ErrorAction SilentlyContinue

# Display schedules for the delivery group
Get-BrokerRebootScheduleV2 -DesktopGroupName $group | Select Name,RestrictToTag,Day,StartTime,Frequency | FT -AutoSize
}



#Show Results
Get-BrokerRebootScheduleV2 | Select Name,RestrictToTag,Day,StartTime,Frequency | Sort-Object Name | FT -AutoSize
Get-BrokerRebootScheduleV2 | Select Name,RestrictToTag,Day,StartTime,Frequency | Sort-Object Name | FT -AutoSize | out-file 'C:\Log\Reboot-Schedules.txt'
Write-host 'Copy of schedules saved to C:\Log\Reboot-Schedules.txt'




