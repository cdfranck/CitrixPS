﻿# Add published content

Add-pssnapin citrix*

$dg = Get-BrokerDesktopGroup -Name "Epic Production"
$content = "http://apwcdir01.childrens.sea.kids/Director"
$appName = "VS Ctx Dir"
New-BrokerApplication -ApplicationType PublishedContent -CommandLineExecutable $content -Name $appName -DesktopGroup $dg.Uid -AdminFolder 'Admins\' -Description $content
