﻿$server = $env:COMPUTERNAME
$session = New-PSSession -ComputerName 'APWCDDC02.childrens.sea.kids'

Invoke-Command -Session $session -ScriptBlock {
    Add-PSSnapin Citrix*
    $guest = $using:server
    $esxhost = Get-BrokerMachine -MachineName "CHILDRENS\$guest" | Select -ExpandProperty HostingServerName
    Add-content -Path "C:\temp\$guest.txt" -Value "$guest is on $esxhost" -Force
}

Move-Item "\\APWCDDC02\c$\temp\$server.txt" "c:\tools\bginfo\esxhost.txt" -Force 

exit



