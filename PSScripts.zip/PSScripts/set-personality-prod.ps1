﻿Remove-Item C:\Personality.ini -Force
Copy-Item "\\apwcx063\c`$\Personality.ini" -Destination C:\Personality.ini -Force
cd c:\scripts
.\C:\Scripts\EnvironmentStartupScript.ps1