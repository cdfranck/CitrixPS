﻿Add-PSSnapin citrix*

$servername = "APWCX098.childrens.sea.kids"

$citrixUsers = Get-BrokerSession -DNSName $servername| Select-Object -ExpandProperty UserName | Sort-Object UserName

$serverUsers = Get-WMIObject –ComputerName "apwcx060" –ClassName Win32_LoggedOnUser | Select-Object Antecedent -Unique | Sort-Object UserName


Write-host "Compares users as seen by Citrix (ledt) and Windows (right)."
Compare-Object -ReferenceObject @($citrixUsers) -DifferenceObject @($serverUsers)


param( [string]$Computer = "apwcx110" )

$instances = Get-WMIObject -Query "SELECT Antecedent FROM Win32_LoggedOnUser" -Namespace "root/cimv2" -Computername $Computer

$count = ( $instances | Measure-Object ).Count
if ( $count -eq 1 ) {
	Write-Host "1 instance:"
} else {
	Write-Host "$count instances:"
}
Write-Host

foreach ( $item in $instances ) {
	Write-Host ($item.Antecedent)
	Write-Host
}$count


