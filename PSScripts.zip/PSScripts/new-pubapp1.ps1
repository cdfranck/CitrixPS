﻿# Create a new published application with a custom icon and filtered users
# Updated 4/28/2020 by cdf

Write-Host "Please enter the following information carefully!"

$newName= Read-Host "Enter the new application name"
$exePath= Read-Host "Enter the path and file name to the executable"
$cmdArg = Read-Host "Enter the command line arguement"
$wrkDir = Read-Host "Enter the working directory (no trailing backslash)"

# Select Admin Folder
Get-BrokerAdminFolder |Select -ExpandProperty Name | Format-List
$folder = Read-Host "Enter the Admin folder name (listed above) with trailing backslash"

# Select available Application groups for use
Get-BrokerApplicationGroup | Select -ExpandProperty Name | Format-List
$appGrp = Read-Host "Enter the Name (listed above) of the Application Group to assign"

# Execute creation of new application
New-BrokerApplication -ApplicationGroup ($appGrp)-Name "$newName" -BrowserName "$newName" -CommandLineExecutable "$exePath" -Enabled $true -PublishedName "$newName" -Visible $true -SecureCmdLineArgumentsEnabled ($cmdArg) -WorkingDirectory "$wrkDir" -ApplicationType HostedOnDesktop -AdminFolderName "$folder"  -WaitForPrinterCreation $false -UserFilterEnabled $true

# Get the New UID
$newUID = Get-BrokerApplication -BrowserName "$newName" | Select UID

# Get the desired icon information
Write-Host "Please make a copy of the executable containing the icon in a temporary location."
$iconexe = Read-Host -Prompt "Enter the Path and filename to pull the desired icon from."
$icon = Get-BrokerIcon -FileName "$iconexe" | New-BrokerIcon | Select-Object UID

# Assign the custom icon
Get-BrokerApplication -Uid $newUID.uid | Set-BrokerApplication -IconUid $icon.uid

# Assign security
$newGrp = Read-Host "Enter the user group, format DOMAIN\Group Name:"
$admUsr = Read-Host "Enter your ID for testing, format DOMAIN\username:"

Add-BrokerUser -Name "$newGrp" -Application $newName
Add-BrokerUser -Name "$admUsr" -Application $newName

Write-Host "If you need to add more groups or users the syntax is: " -NoNewline
Write-Host 'Add-BrokerUser -Name "DOMAIN\User or Group" -Application "Your Application Name"' -ForegroundColor yellow -BackgroundColor Black

# REPORT: Show Results
Write-host "Application Info:" -ForegroundColor Green
Write-host "-----------------" -ForegroundColor Green
Get-BrokerApplication -BrowserName $newName | Select UID,Name,ApplicationName,BrowserName,PublishedName,CommandLineExecutable,CommandLineArguments,WorkingDirectory,AdminFolderName | fl
Write-host "Assigned users and devices for $newName :" -ForegroundColor Green
Write-host "---------------------------" -ForegroundColor Green
Get-BrokerUser -ApplicationUid $newUID.uid | Select Name
Get-BrokerApplicationGroup -ApplicationUid $newUID.uid | Select Name,TotalMachines |fl

#Delete the app
$fullname = Get-BrokerApplication -BrowserName $newName | Select Name
Write-Host "If you need to delete this application here is the syntax:"
Write-Host -BackgroundColor Black -ForegroundColor Yellow 'Remove-BrokerApplication -Name "AdminFolderName\ApplicationName" -ApplicationGroup "ApplicationGroupName"'
Write-Host -ForegroundColor DarkYellow "Alternately, you can use the variables fullname for -Name and appGrp for -ApplicationGroup."