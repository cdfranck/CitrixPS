﻿remove-item c:\temp\nonproduptime.txt -ErrorAction SilentlyContinue

Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX001 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX002 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX004 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX005 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX006 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX007 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX008 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX009 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX010 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX011 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX012 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX013 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX014 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX015 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName ATWCX016 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append
Get-CimInstance -ClassName win32_operatingsystem -ComputerName APWCX002 | select csname,lastbootuptime | Out-File c:\temp\nonproduptime.txt -Append

Write-Host "Results available in c:\temp\nonproduptime.txt"
exit