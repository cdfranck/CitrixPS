﻿Start-Process 'C:\Program Files (x86)\Epic\v9.3\Shared Files\Barcodifier.exe'
start-process 'C:\Program Files (x86)\Epic\v9.3\Shared Files\EpicD93.exe' -ArgumentList "ENV=ACE01" -WorkingDirectory 'C:\Program Files (x86)\Epic\v9.3\Shared Files'
exit