﻿Add-PSSnapin citrix*
remove-item c:\log\users*.htm -Force
$timestamp = get-date -DisplayHint DateTime
$FileName = "Users_" + (get-date).tostring("ddMMMyyyy_hhmmtt") + ".htm"


Import-Module C:\users\de-cfran5\Documents\HTMLTable.psm1

# Get data
$all = (Get-BrokerSession -DesktopGroupName "Epic Production" -MaxRecordCount 5000).count
$disc = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Disconnected -MaxRecordCount 5000).count
$act = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Active -MaxRecordCount 5000).count
$pre = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState PreparingSession -MaxRecordCount 5000).count
$conn = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Connected -MaxRecordCount 5000).count
$recon = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Reconnecting -MaxRecordCount 5000).count
$otr = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Other -MaxRecordCount 5000).count
$unk = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Unknown -MaxRecordCount 5000).count
$non = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState NonBrokeredSession -MaxRecordCount 5000).count
$allenv = (Get-BrokerSession -SessionState Active -AppState Active -MaxRecordCount 5000| select UntrustedUserName -Unique).count
$alldis = (Get-BrokerSession -SessionState Disconnected -MaxRecordCount 5000| select UntrustedUserName -Unique).count
$unique = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Active -AppState Active -MaxRecordCount 5000| select UntrustedUserName -Unique).count
$allusers = (Get-BrokerSession -DesktopGroupName "Epic Production" -SessionState Active -AppState Active -MaxRecordCount 5000| select UntrustedUserName).count
$dupes = ($allusers-$unique)


#Build HTML header
$HTML = New-HTMLHead -title "User Summary Report"

#Add Data
$HTML += "<h2>User Session Report</h2>" | Close-HTML
$HTML += "<p>Report created: $timestamp</p>" | Close-HTML
$HTML += "</hr>" | Close-HTML
$HTML += "<h3>All active users with an app, all environments: $allenv </h3>" | Close-HTML
$HTML += "<h3>All Active Epic Prod users with an app: $allusers </h3>" | Close-HTML
$HTML += "<h3>Duplicate users in Epic Prod: $dupes </h3>"| Close-HTML
$HTML += "<h3>All disconnected users, all environments: $alldis </h3>" | Close-HTML
$HTML += "<h3>All reported Epic Prod sessions: $all </h3>"| Close-HTML
$HTML += "<h3>All Prod UNIQUE users: $unique </h3>"| Close-HTML
$HTML += "<h3>Epic Prod Connected: $conn </h3>"| Close-HTML
$HTML += "<h3>Epic Prod Disconnected: $disc </h3>"| Close-HTML
$HTML += "<h3>Epic Prod Reconnecting: $recon </h3>"| Close-HTML
$HTML += "<h3>Epic Prod Pre-logon: $pre </h3>"| Close-HTML
$HTML += "<h3>Epic Prod Active: $act </h3>"| Close-HTML
$HTML += "<h3>Epic Prod Other: $otr </h3>"| Close-HTML
$HTML += "<h3>Epic Prod Unknown: $unk </h3>"| Close-HTML
$HTML += "<h3>Epic Prod Non-Brokered: $non </h3>"| Close-HTML



#write the HTML to a file 
set-content "C:\Log\$FileName" $HTML


# Email report (reusable block)
$from = "APWCDDC01@seattle.childrens.org"
$subject = "User Summary"
$sendto = "candi.franck@virtustream.com"
$report = "c:\Log\$FileName"
$port = "25"
$smtpsvr = "email.seattlechildrens.org"
Send-MailMessage -From $from -Subject $subject -To $sendto -Attachments $report -Port $port -SmtpServer $smtpsvr