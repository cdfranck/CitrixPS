﻿# Adding\Removing Groups or Users from a Published Application

Add-PSSnapin Citrix*

# Find the Name and UID for the desired application
Get-BrokerApplication | Select Name,UID

#Example: Non-Prod\Notepad  7

# Review the current security
Get-BrokerUser -ApplicationUid 7

# Add a user or group
Add-BrokerUser "Childrens\cfran5" -Application "Non-Prod\Notepad"

# Remove a user or group
Remove-BrokerUser "Childrens\de-cfran5" -Application "Non-Prod\Notepad"