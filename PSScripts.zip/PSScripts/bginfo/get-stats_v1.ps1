﻿# Reset data
CLEAR
Remove-item c:\bginfo\bginfo.txt -force -ErrorAction SilentlyContinue
Remove-Item C:\bginfo\bginfo.htm  -force -ErrorAction SilentlyContinue
$sysinfo = New-Item -ItemType File -Path c:\bginfo\bginfo.txt

# Start
Add-Content -Path $sysinfo -Value "<p>"
Add-Content -Path $sysinfo -Value "Started:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-Date -DisplayHint DateTime)
Add-Content -Path $sysinfo -Value "</p>"

# Get OS Information
Add-Content -Path $sysinfo -Value "*------------------------------OS Info:------------------------------*" 
Add-Content -Path $sysinfo -Value "<p><h1>"
Add-Content -Path $sysinfo -Value "Server Name:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property CsCaption |Select -ExpandProperty CsCaption)
Add-Content -Path $sysinfo -Value "</h1></br>"

Add-Content -Path $sysinfo -Value "Operating System:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property OsName |Select -ExpandProperty OsName)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "OS Version:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property OsVersion |Select -ExpandProperty OsVersion)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "Features:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property OSSuites | Select -ExpandProperty OSSuites)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "OS Last BootUp Time:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property OsLastBootUpTime |Select -ExpandProperty OsLastBootupTime)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "OS Local Time:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property OsLocalDateTime |Select -ExpandProperty OsLocalDateTime) -NoNewline
Add-Content -Path $sysinfo -Value (Get-TimeZone |Select -ExpandProperty Id)
Add-Content -Path $sysinfo -Value "</p>"

# Get Installed Hotfixes
Add-Content -Path $sysinfo -Value "*------------------------------Hotfixes:------------------------------*" 
Add-Content -Path $sysinfo -Value "<p>"
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property OsHotFixes | Select -ExpandProperty OSHotFixes | foreach{$_.HotFixID})
Add-Content -Path $sysinfo -Value "</p>"

# Get Memory Information
Add-Content -Path $sysinfo -Value "*------------------------------Proc & Mem:----------------------------*" 
Add-Content -Path $sysinfo -Value "<p>"
Add-Content -Path $sysinfo -Value "Processors:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-CimInstance -ClassName CIM_Processor | Select DeviceID,Name | foreach{$_.DeviceID,$_.Name})
Add-Content -Path $sysinfo -Value "</br>"

$TotVisMem = Get-ComputerInfo -Property OsTotalVisibleMemorySize | Select -ExpandProperty OsTotalVisibleMemorySize
$TotVirtMem = Get-ComputerInfo -Property OsTotalVirtualMemorySize| Select -ExpandProperty OsTotalVirtualMemorySize 
$FreeVirtMem = Get-ComputerInfo -Property OsFreeVirtualMemory | Select -ExpandProperty OsFreeVirtualMemory      
$InUseMem = Get-ComputerInfo -Property OsInUseVirtualMemory | Select -ExpandProperty OsInUseVirtualMemory    
$FreeMem = Get-ComputerInfo -Property OsFreePhysicalMemory | Select -ExpandProperty OsFreePhysicalMemory   
  
Add-Content -Path $sysinfo -Value "Total Visible Memory (GB):  " -NoNewline 
Add-Content -Path $sysinfo -Value (([math]::Round($TotVisMem/1MB,3)))
Add-Content -Path $sysinfo -Value "</br>"
Add-Content -Path $sysinfo -Value "Free Visible Memory (GB):  " -NoNewline 
Add-Content -Path $sysinfo -Value (([math]::Round($FreeMem/1MB,3)))
Add-Content -Path $sysinfo -Value "</br>"
Add-Content -Path $sysinfo -Value "Total Virtual Memory (GB):  " -NoNewline 
Add-Content -Path $sysinfo -Value (([math]::Round($TotVrtMem/1MB,3)))
Add-Content -Path $sysinfo -Value "</br>"
Add-Content -Path $sysinfo -Value "Free Virtual Memory (GB):  " -NoNewline 
Add-Content -Path $sysinfo -Value (([math]::Round($FreeVirtMem/1MB,3)))
Add-Content -Path $sysinfo -Value "</br>"
Add-Content -Path $sysinfo -Value "In Use Memory (GB):  " -NoNewline 
Add-Content -Path $sysinfo -Value (([math]::Round($InUseMem/1MB,3)))
Add-Content -Path $sysinfo -Value "</p>"

# Get Volume Information
Add-Content -Path $sysinfo -Value "*------------------------------Storage:------------------------------*" 
Add-Content -Path $sysinfo -Value "<p>"
Add-Content -Path $sysinfo -Value (Get-Volume | Select @{L="Drive";E={$_.DriveLetter}},@{L="Health";E={$_.HealthStatus}},@{L='% Used';E={($_.SizeRemaining/$_.size).ToString("P")}},@{L="Size (GB)";E={[math]::Round($_.Size/1GB,3)}} | Sort-Object Drive)
Add-Content -Path $sysinfo -Value "</p>"

# Get Netowrk Information
Add-Content -Path $sysinfo -Value "*------------------------------Network:------------------------------*" 
Add-Content -Path $sysinfo -Value "<p>"

Add-Content -Path $sysinfo -Value "DNS Name:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property CsDNSHostName |Select -ExpandProperty CsDNSHostName)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "Domain:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property CsDomain |Select -ExpandProperty CsDomain)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "Logon Server:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-ComputerInfo -Property LogonServer |Select -ExpandProperty LogonServer)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "NIC:  " -NoNewline
$nicint = Get-NetIPConfiguration |Select -ExpandProperty InterfaceAlias
Add-Content -Path $sysinfo -Value "$nicint"
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "Driver:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-NetIPConfiguration |Select -ExpandProperty InterfaceDescription)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "IP Address:  " -NoNewline
Add-Content -Path $sysinfo -Value (get-netipaddress -AddressFamily IPv4 -InterfaceAlias $nicint |Select -ExpandProperty IPAddress)
Add-Content -Path $sysinfo -Value "</br>"

Add-Content -Path $sysinfo -Value "MAC Address:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-NetAdapter |Select -ExpandProperty MACAddress)
Add-Content -Path $sysinfo -Value "</p>"

# Set Wallpaper based on flag -- MUST BE an appropriately named JPG in the BGInfo folder (prod.jpg/nonprod.jpg)
import-module C:\bginfo\Set-Wallpaper.psm1

If(Test-Path C:\bginfo\prod.jpg -PathType leaf) {
    Add-Content -Path $sysinfo -Value "<p><h1>"
    Add-Content -Path $sysinfo -Value "!!DANGER WILL ROBINSON!!!  ---  PRODUCTION SYSTEM"
    Add-Content -Path $sysinfo -Value "</h1></p>"
    Set-WallPaper -Image "C:\bginfo\prod.jpg" -Style Fill
 
}
Elseif (Test-Path C:\bginfo\nonprod.jpg -PathType leaf) {
    Add-Content -Path $sysinfo -Value "<p><h2>"
    Add-Content -Path $sysinfo -Value "SAFEZONE  ---  NON-PROD SYSTEM"
    Add-Content -Path $sysinfo -Value "</h2></p>"
    Set-WallPaper -Image "C:\bginfo\nonprod.jpg" -Style Fill
 
}
 
# End of Script
Add-Content -Path $sysinfo -Value "<p>"
Add-Content -Path $sysinfo -Value "Completed:  " -NoNewline
Add-Content -Path $sysinfo -Value (Get-Date -DisplayHint DateTime)
Add-Content -Path $sysinfo -Value "</p>"

# Display
$header = @"
    <style>
      body {background-color: yellow;}
      h1 {color: red;}
      h2 {color: blue;}
    </style>
"@

ConvertTo-Html -Body (get-content $sysinfo) -Head $header -PostContent ("Generated by Virtustream EPIC AMS Team") -PreContent ("Open an incident to 'Epic Support - Coordination' for issues.") -Title "YOU ARE HERE"| Out-File c:\bginfo\bginfo.htm
invoke-item C:\bginfo\bginfo.htm