﻿# Reset Perfmon Counters
Stop-Service brokeragent -force
Start-Sleep 5
Get-Service BrokerAgent
Start-Sleep 5
lodctr.exe /R
Start-Sleep 5
lodctr.exe /R
Start-Sleep 5
winmgmt.exe /RESYNCPERF
Start-Sleep 5
winmgmt.exe /RESYNCPERF
Start-Sleep 5
Start-Service brokeragent
Start-Sleep 5
Get-Service BrokerAgent

# Clear event logs
$logs = Get-EventLog -List | ForEach-Object {$_.Log}
ForEach ($log in $logs) {Clear-EventLog -LogName $log}
Get-EventLog -List

# Empty Recycle Bin
Clear-RecycleBin -Force -Verbose

Exit